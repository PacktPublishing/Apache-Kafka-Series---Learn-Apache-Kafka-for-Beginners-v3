#pragma once

#define KAFKACAT_VERSION "1.4.0" /* Manually updated */
